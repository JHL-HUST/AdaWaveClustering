
# THIS FILE IS GENERATED FROM PYWAVELETS SETUP.PY
short_version = '0.5.2'
version = '0.5.2'
full_version = '0.5.2'
git_revision = 'a0bae270614700510e93c50b7559b7ca912517ef'
release = True

if not release:
    version = full_version
